export default async function handler(req, res) {
  try {
    if (req.method !== 'GET') {
      return res.status(405).json({ error: 'Method not allowed' });
    }

    const { freq, intensity } = req.query;
    if (freq && isNaN(Number(freq))) {
      return res.status(400).json({ error: 'Invalid freq parameter' });
    }

    const f = Number(freq) || 432;
    const i = Number(intensity) || 0.6;

    const signals = [
      { id: 'GS-01', type: 'Ground Station', freq: f - 12, strength: 92 + Math.random() * 6 },
      { id: 'SAT-Alpha', type: 'LEO Comms', freq: f + 45, strength: 78 + Math.random() * 10 },
      { id: 'GRID-RESONANCE', type: 'Sky Grid Harmonic', freq: f, strength: Math.floor(i * 95) }
    ];

    res.status(200).json({ signals, timestamp: Date.now() });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
}
