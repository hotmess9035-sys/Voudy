import { kv } from '@vercel/kv';

export default async function handler(req, res) {
  try {
    if (req.method !== 'POST' && req.method !== 'GET') {
      return res.status(405).json({ error: 'Method not allowed' });
    }

    const user = req.query.user || req.body?.user || 'default';

    await kv.del(`state:${user}`);

    res.status(200).json({ 
      status: 'purged', 
      timestamp: Date.now(),
      message: 'Kill switch engaged - all traces removed' 
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
}
