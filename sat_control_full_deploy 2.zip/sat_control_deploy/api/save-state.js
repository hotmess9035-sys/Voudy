import { kv } from '@vercel/kv';

export default async function handler(req, res) {
  try {
    if (req.method !== 'POST') {
      return res.status(405).json({ error: 'Method not allowed' });
    }

    const { user = 'default', state } = req.body || {};
    if (!state) {
      return res.status(400).json({ error: 'Missing state' });
    }

    await kv.set(`state:${user}`, state, { ex: 86400 }); // 24h TTL example

    res.status(200).json({ ok: true, saved: Date.now() });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
}
