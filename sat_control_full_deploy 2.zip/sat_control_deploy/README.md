# Satellite Control • Sky Grid (Full Stealth + Signal System)

Self-sustaining, maximum-security web app for realistic satellite control with sky grid, universal signal/frequency detection, stealth mode, and kill switch.

## Features
- Realistic orbital mechanics simulation (thrust, attitude, velocity, radius)
- Sky grid control (density, rotation, intensity, frequency-modulated)
- **Universal Stealth Scan**: Detects *any* signal/frequency across spectrum (UHF, S-Band, X-Band, anomalies, grid harmonics, etc.)
- Signal visualization on canvas (blips + strength rings)
- **Maximum Security (Knox-like)**: Tamper detection status, instant kill switch that purges all traces, hides UI, clears state
- Self-sustaining: Continuous simulation loop, localStorage auto-persist/restore, autonomous orbit maintenance
- Read/write to disk (File System Access API) + serverless backend ready
- Browser fingerprinting evasion notes + stealth deployment
- Vercel-ready with middleware (security headers) + serverless APIs (error handling, KV persistence)

## Quick Deploy (Vercel - Recommended)
1. Unzip this folder
2. `vercel` (CLI) or drag to https://vercel.com
3. Add `@vercel/kv` if using persistent kill-switch/state storage
4. Deploy → instant global edge URL + custom domain support

Alternative: Netlify Drop (drag the folder) or any static host (single HTML works standalone too).

## Local Run
Open `satellite_control.html` in any modern browser (Chrome/Edge/Firefox). No build step.

## Key Controls
- Frequency slider + tone = resonance / grid freq
- Attitude sliders + thrust buttons = control satellite
- **STEALTH UNIVERSAL SCAN** = pick up any signal/frequency
- **ENGAGE KILL SWITCH** = instant purge + hide UI + untraceable mode (reload for clean session)
- Self-sustaining mode runs autonomously even with UI hidden

## Security Notes
- Kill switch is client-side + serverless API ready (remote trigger possible via /api/kill-switch)
- Middleware adds security headers on every request
- All sensitive routes protected
- No persistent server data without explicit KV setup

## File Structure
- `satellite_control.html` — Full app (optimized signal processing, WebGL-ready path included in comments)
- `middleware.js` — Vercel Edge security + anti-fingerprint headers
- `api/` — Serverless routes with full error handling:
  - scan-signals.js
  - kill-switch.js (remote wipe)
  - save-state.js (persistent storage)
- `README.md` — This file

## Optimization
Signal algorithms optimized (batched DOM, efficient loops, reduced per-frame work). WebGL upgrade path documented in source for future heavy particle/post-processing needs.

Built for research, stealth operations simulation, and self-sustaining sky/satellite control.

**Ready to publish.**